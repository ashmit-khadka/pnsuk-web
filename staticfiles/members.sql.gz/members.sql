INSERT INTO member_member (forename, surname, role, position )
VALUES ('Shiva', 'Bhandari', 'President', 'Executive');
INSERT INTO member_member (forename, surname, role, position)
VALUES ('Rabi', 'Acharya', 'Vice President', 'Executive');
INSERT INTO member_member (forename, surname, role, position)
VALUES ('Dhurba', 'Dhital', 'Vice President', 'Executive');